# MS Surveyor App

Upload CSV, view map, add notes.
Deploy backend on Render, frontend on Vercel.