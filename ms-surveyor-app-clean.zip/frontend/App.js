// Your React frontend entry point
import React from 'react';
export default function App() {
  return <div>MS Surveyor App</div>;
}
